from machine import Pin
import utime
buz = Pin(15, Pin.OUT)


while True:
 
  

  utime.sleep(0.5)
